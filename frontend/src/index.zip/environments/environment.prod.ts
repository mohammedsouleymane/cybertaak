export const environment = {
  production: true,
  configFile: 'assets/config/config.dev.json'
};
