export enum State
{
  Todo = 0,
  InProgess = 1,
  Done = 2
}
